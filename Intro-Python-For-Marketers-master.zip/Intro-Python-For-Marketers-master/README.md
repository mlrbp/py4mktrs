# Intro-Python-For-Marketers
These are the workbooks for the Intro to Python for Markters YouTube series. Download then visit databoi.com. 
